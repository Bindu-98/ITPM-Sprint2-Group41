/**
 * 
 */
package Service;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class coup {
	
	public ArrayList<int[]> getscore(String code) {
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='cou'");
			  // displaying records
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		
		
		
		ArrayList<int[]> score= new ArrayList<int[]>();
		int Ccp  ,Nr , Nmcms, Nmcmd, Nmcrms, Nmcrmd, Nrmcrms,Nrmcrmd, Nrmcms, Nrmcmd, Nmrgvs, Nrmrgvs,Nmrgvd, Nrmrgvd;

		String statement[] =code.split("\n");
		
		for(int iln = 0 ; iln < statement.length ; iln++)
		{	
			Ccp =0;
			Nr =0;
			Nmcms=0;
			Nmcmd=0;
			Nmcrms=0;
			Nmcrmd=0;
			Nrmcrms=0;
			Nrmcrmd=0;
			Nrmcms=0;
			Nrmcmd=0;
			Nmrgvs=0;
			Nmrgvd=0;
			Nrmrgvs=0;
			Nrmrgvd=0;
			
			statement[iln]=statement[iln].trim();
			  Pattern re=Pattern.compile("[A-Za-z]+[(].*[)][;]");
			  Matcher m = re.matcher(statement[iln]);
			  while(m.find()) { 
				  System.out.println(iln-1);
				  Nmcms=1; 
				  
			  }
			  
			  re=Pattern.compile("[(].*[A-Za-z]+[(].*[)]");
				  m = re.matcher(statement[iln]);
				  while(m.find()) { 
					  Nmcms++;
			   }
				  
			   re=Pattern.compile("(^\\s*[=])");
				  m = re.matcher(statement[iln]);
				  while(m.find()) { 
					  Nmrgvs++;
			   }
				  
				  re=Pattern.compile("[^(].*?[a-z]+\\s*[,|/|\\+|\\*|\\)]");
				  m = re.matcher(statement[iln]);
				  while(m.find()) { 
					  Nmrgvs++;
			   }
			  
			
			try {
				Ccp =( rs.getInt(2)* Nr) + ( rs.getInt(3) * Nmcms) + ( rs.getInt(4) * Nmcmd) + ( rs.getInt(5) * Nmcrms)+ ( rs.getInt(6)* Nmcrmd)+ ( rs.getInt(7)* Nrmcrms)+( rs.getInt(8)*Nrmcrmd) + ( rs.getInt(9)* Nrmcms)+ ( rs.getInt(10) * Nrmcmd) + ( rs.getInt(11) *Nmrgvs) + ( rs.getInt(12)* Nmrgvd)+ ( rs.getInt(13)* Nrmrgvs)+ ( rs.getInt(14)* Nrmrgvd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			score.add(new int[] {Nr,Nmcms,Nmcmd,Nmcrms,Nmcrmd,Nrmcrms,Nrmcrmd,Nrmcms,Nrmcmd,Nmrgvs,Nmrgvd,Nrmrgvs,Nrmrgvd,Ccp});


		}	
		return score;
	}


}