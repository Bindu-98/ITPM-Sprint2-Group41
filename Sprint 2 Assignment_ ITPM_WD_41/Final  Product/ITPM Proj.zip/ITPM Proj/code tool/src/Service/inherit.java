/**
 * 
 */
package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class inherit {
	
	
	
	public ArrayList<int[]> getscore(String code) {
		ArrayList<int[]> score= new ArrayList<int[]>();
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='inh'");
			  // displaying records
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		String statement[] =code.split("\n");

		for(int ln = 0 ; ln < statement.length ; ln++)
		{
			  int inv=0;
			  
			  
			  int Winh=1;
			try {
				Winh = rs.getInt(2);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			  statement[ln]=statement[ln].trim();
			  Pattern r = Pattern.compile("extends");
			  Matcher m = r.matcher(statement[ln]);
			  if(m.find()) {  
				     
				 
				  inv=1*Winh;
				  
			  }
			  
			score.add(new int[] {inv});


		}	
		return score;
	}

	

}
