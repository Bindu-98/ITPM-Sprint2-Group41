/**
 * 
 */
package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author DELL
 *
 */
public class var {
	


	int Wvs  ,Npdtv ,Ncdtv ,Cv, curc,curm, counc,counm,classb,methb ;
	
	public ArrayList<int[]> getscore(String code) {
		ArrayList<int[]> score= new ArrayList<int[]>();
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='var'");
			  // displaying records
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		

		
		String statement[] =code.split("\n");

		counm=-1;
		counc=-1;
		classb=0;
		methb=0;
		Wvs = 0 ;
		
		for(int i = 0 ; i < statement.length ; i++)
		{
			Wvs = 0 ;
			Npdtv = 0;
			Ncdtv=0;
			Cv=0;
			
			System.out.print(i+" ") ;
			System.out.print(statement[i]+" ");
			

			  statement[i]=statement[i].trim();
			  Pattern re=Pattern.compile("^\\s*class\\s+");
			  Matcher m = re.matcher(statement[i]);
			  if(m.find()) { 
				  counc++;
				  curc=counc;
			  }
			  
			  re = Pattern.compile("(void|int|String|boolean|float)\\s+(\\S+)\\s*[(]");
			  m = re.matcher(statement[i]);
			  if(m.find()) {  
				  counm++;
				  curm=counm;
				  
			  }
			  
			  re = Pattern.compile("\\{");
			  m = re.matcher(statement[i]);
			  while(m.find()) {  
				  if(curm>-1) {
					  classb++;
					  methb++;
					  
				  }else {
					  classb++;
				  }
				  
			  }
			  
			  re = Pattern.compile("\\}");
			  m = re.matcher(statement[i]);
			  while(m.find()) {  
				  if(curm>-1) {
					  classb--;
					  methb--;
					  if(methb==0)
						  curm=-1;
					  
				  }else {
					  classb=0;
					  curc=-1;
				  }
				  
			  }
			  
			  
			  re = Pattern.compile("^\\s*(class|public|for|if|return|while)");
			  m = re.matcher(statement[i]);
			  if(m.find()) {  
			  
			  }else {
				  re = Pattern.compile("^\\s*(\\S+)[(]");
				  m = re.matcher(statement[i]);
				  if(m.find()) {  
				  

				  }else {
					   try {
						   re = Pattern.compile("^\\s*(int|char|boolean|double|float)");
					  m = re.matcher(statement[i]);
					  if(m.find()) {  
						  if(curm>-1) {
							  Wvs=rs.getInt(2);
							  Npdtv=1;
						  }
						  else {
							  Wvs=rs.getInt(3);
							  Npdtv=1;
						  }
					  }else {
					  
						  re = Pattern.compile("^\\s*(\\S+)\\s+(\\S+)");
						  m = re.matcher(statement[i]);
						  if(m.find()) {  
							  if(curm>-1) {
								 
									Wvs=rs.getInt(2);
								
								  Ncdtv=1;
							  }
							  else {
								  Wvs=rs.getInt(3);;
								  Ncdtv=1;
							  }
						  }
					  }
					  
					  } catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
					  }
				  }
			  }
			
		//	Cv=Wvs*((Integer.parseInt(c.hm.get("wpdtv"))* Npdtv) + (Integer.parseInt(c.hm.get("wcdtv"))* Ncdtv));

		
			score.add(new int[] {Wvs,Npdtv,Ncdtv,Cv});

		}	
		return score;
	}


}