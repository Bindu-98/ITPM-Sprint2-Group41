/**
 * 
 */
package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class meth {
	
	int Wmrt  ,Npdtp ,Ncdtp ,Cm ;
	
	public ArrayList<int[]>  getscore(String code) {
		
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='met'");
			  // displaying records
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		
		
		ArrayList<int[]> score= new ArrayList<int[]>();
	
		String statement[] =code.split("\n");
		
		for(int i = 0 ; i < statement.length ; i++)
		{
			Wmrt = 0 ;
			Npdtp = 0;
			Ncdtp=0;
			Cm=0;
			
			  statement[i]=statement[i].trim();
			  Pattern re = Pattern.compile("(void|int|String|boolean|float|double)\\s+(\\S+)\\s*[(]([a-zA-Z]*)");
			  Matcher m = re.matcher(statement[i]);
			  if(m.find()) {  
				      String s = m.group(1);
				      // s now contains "BAR"
				  try {
				  
				  String ret3=m.group(3);
				  if(ret3.equals(""))
					  Ncdtp = 0 ;
				  else if(ret3.equals("int")||ret3.equals("float")||ret3.equals("double")||ret3.equals("boolean"))
					  Ncdtp = rs.getInt(2) ;
				  else 
					  Ncdtp = rs.getInt(3);
				  
				  
				  String ret=m.group(1);
				  if(ret.equals("void"))
					
						Wmrt = rs.getInt(6);
					
				else if(ret.equals("int")||ret.equals("float")||ret.equals("double")||ret.equals("boolean"))
					  Wmrt = rs.getInt(4);
				  else
					  Wmrt = rs.getInt(5);
				} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  
			  }
			  
			  
			
			Cm= Wmrt+ (1 * Npdtp) + (1 * Ncdtp) ;
			score.add(new int[] {Wmrt,Npdtp,Ncdtp,Cm});


		}	
		return score;
	}
	

}
