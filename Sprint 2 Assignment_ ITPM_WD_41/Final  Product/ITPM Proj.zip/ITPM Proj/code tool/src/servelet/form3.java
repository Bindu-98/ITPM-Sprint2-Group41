package servelet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class form1
 */
@WebServlet("/form3")
public class form3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public form3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		try {
		  Connection con = null;  
		  Statement stmt = null;
		  ResultSet rs = null;
		  Class.forName("com.mysql.jdbc.Driver");
		  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
		  stmt = con.createStatement();
		  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='met'");
		  // displaying records
		  rs.next();
	  
		  response.setContentType("text/html");
		  request.setAttribute("w", new int[] {rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9),rs.getInt(10)});
		  rd = getServletContext().getRequestDispatcher("/form_3.jsp");
		  rd.forward(request, response);
		
		}catch(Exception e2){
			
			System.out.print("44");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher rd;
		try {
		  Connection con = null;  
		  Statement stmt = null;
		  ResultSet rs = null;
		  Class.forName("com.mysql.jdbc.Driver");
		  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
		  stmt = con.createStatement();
		  String str="update  weights set w1="+request.getParameter("w1")+",w2="+request.getParameter("w2")+",w3="+request.getParameter("w3")+",w4="+request.getParameter("w4")+",w5="+request.getParameter("w5")+",w6="+request.getParameter("w6")+",w7="+request.getParameter("w7")+",w8="+request.getParameter("w8")+",w9="+request.getParameter("w9")+",w10="+request.getParameter("w10")+",w11="+request.getParameter("w11")+" where wtype='met'";
		  stmt.execute(str);
		 // rs.next();
	  
		  response.setContentType("text/html");
		  //request.setAttribute("w", new int[] {rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9),rs.getInt(10)});
		  rd = getServletContext().getRequestDispatcher("/index.jsp");
		  rd.forward(request, response);
		
		}catch(Exception e2){
			
			System.out.print("44");
		}
		
		
		
		
	}

}
